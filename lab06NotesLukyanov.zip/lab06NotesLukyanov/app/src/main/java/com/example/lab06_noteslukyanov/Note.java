package com.example.lab06_noteslukyanov;

public class Note
{
    public String title;
    public String content;

    public String toString()
    {
        return  title;
    }
}
