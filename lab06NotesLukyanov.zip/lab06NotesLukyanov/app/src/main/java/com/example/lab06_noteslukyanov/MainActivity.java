package com.example.lab06_noteslukyanov;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    ArrayAdapter <Note> adp;
    ListView lst;
    int pos, sel;
    String title, content;
    Note n;
    Intent i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        adp = new ArrayAdapter<Note>(this, android.R.layout.simple_list_item_1);

        lst = findViewById(R.id.lst_notes);
        lst.setAdapter(adp);
        
        lst.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                sel = position;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        if (data != null)
        {
            pos = data.getIntExtra("my-note-index", -1);

            title = data.getStringExtra("my-note-title");
            content = data.getStringExtra("my-note-content");

            n = adp.getItem(pos);
            n.title = title;
            n.content = content;

            adp.notifyDataSetChanged();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void New_OnClick(View v)
    {
        n = new Note();
        n.title = "New note";
        n.content = "New content";

        adp.add(n);
        pos = adp.getPosition(n);

        i = new Intent(this, NoteActivity.class);
        i.putExtra("my-note-index", pos);
        i.putExtra("my-note-title", n.title);
        i.putExtra("my-note-content", n.content);

        startActivityForResult(i, 12345);
    }

    public void Edit_OnClick(View v)
    {

    }

    public void Delete_OnClick(View v)
    {

    }
}